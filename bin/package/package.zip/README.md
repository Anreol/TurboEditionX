# TurboEditionX
> X stands for "Xtra Mod X Compatibility"

Addon to [Turbo Edition](https://github.com/Anreol/TurboEdition) which has a hard dependency on.
Adds support to: 
- [CustomEmotes API](https://thunderstore.io/package/MetrosexualFruitcake/CustomEmotesAPI/)
- TODO: ~~[Ancient Scepter](https://thunderstore.io/package/amogus_lovers/StandaloneAncientScepter/)~~
